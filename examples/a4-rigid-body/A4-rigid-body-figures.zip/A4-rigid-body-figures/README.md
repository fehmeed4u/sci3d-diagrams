# A.4 Rigid Body Mechanics — figure index

All figures: 1800 × 1280 px transparent PNG, IB exam style 2D line art, sans-serif labels.

- `light/` — black lines, for white slides
- `dark/` — white lines (shape fills #141d35), for dark slides

| File | Lesson | Slide | Title |
|---|---|---|---|
| `fig-1a-review.png` | 1 – Torque | Review slide 01 | Spanner on a nut: torque and perpendicular distance |
| `fig-1b-challenge.png` | 1 – Torque | Challenge slide 02 | Hinged beam held by a cable |
| `fig-2a-review.png` | 2 – Angular velocity | Review slide 05 | Rotating disc: v = ωr and centripetal acceleration |
| `fig-2b-challenge.png` | 2 – Angular velocity | Challenge slide 06 | Braking wheel and ω–t graph |
| `fig-3a-review.png` | 3 – Moment of inertia | Review slide 09 | Standard moments of inertia |
| `fig-3b-challenge.png` | 3 – Moment of inertia | Challenge slide 10 | Rod with movable end masses |
| `fig-4a-review.png` | 4 – Rotational kinetic energy | Review slide 13 | Rolling wheel velocity profile |
| `fig-4b-challenge.png` | 4 – Rotational kinetic energy | Challenge slide 14 | Solid cylinder rolling down a slope |
| `fig-5a-review.png` | 5 – Angular momentum | Review slide 17 | Spinning skater: conservation of angular momentum |
| `fig-5b-challenge.png` | 5 – Angular momentum | Challenge slide 18 | Clay dropped onto a turntable |

## Details

### `fig-1a-review.png` — Spanner on a nut: torque and perpendicular distance
Lesson 1 (Torque), Review slide 01.

Ring spanner on a hex nut (pivot). Force F at the end at angle θ to the handle; r dimensioned from nut centre to point of application; line of action extended (dashed) with perpendicular r⊥ from pivot and right-angle mark; r⊥ = r sin θ. Inset: couple — equal and opposite forces F on a steering wheel, separation 2r.

Light: `light/fig-1a-review.png` · Dark: `dark/fig-1a-review.png`

### `fig-1b-challenge.png` — Hinged beam held by a cable
Lesson 1 (Torque), Challenge slide 02.

Hatched wall with hinge; horizontal uniform beam 6.0 m, 40 kg. Cable from far end to wall at 30° to the beam, tension T along the cable. Weight W from the midpoint (3.0 m). 20 kg load on a string at 4.5 m. Dimensions from hinge: 3.0 m, 4.5 m, 6.0 m. Unknown hinge force R (dashed arrow, angle unspecified).

Light: `light/fig-1b-challenge.png` · Dark: `dark/fig-1b-challenge.png`

### `fig-2a-review.png` — Rotating disc: v = ωr and centripetal acceleration
Lesson 2 (Angular velocity), Review slide 05.

Disc rotating anticlockwise about O, curved arrow ω. Points P (at r) and Q (at 2r) on one radius with tangential velocity arrows v and 2v (twice as long). Centripetal acceleration arrow a from Q towards O. Side notes: v = ωr, a = ω²r (at Q: a = ω²(2r)).

Light: `light/fig-2a-review.png` · Dark: `dark/fig-2a-review.png`

### `fig-2b-challenge.png` — Braking wheel and ω–t graph
Lesson 2 (Angular velocity), Challenge slide 06.

Spoked wheel with brake pad on the rim, curved arrow 1200 rpm. ω–t sketch: straight line from ω₀ to 0 at t = ?; area under the line hatched and labelled 25 rev.

Light: `light/fig-2b-challenge.png` · Dark: `dark/fig-2b-challenge.png`

### `fig-3a-review.png` — Standard moments of inertia
Lesson 3 (Moment of inertia), Review slide 09.

Four shapes with dashed rotation axes: rod about centre I = 1/12 mL²; rod about end I = 1/3 mL²; disc about central axis I = 1/2 mr²; solid sphere I = 2/5 mr². L or r marked on each.

Light: `light/fig-3a-review.png` · Dark: `dark/fig-3a-review.png`

### `fig-3b-challenge.png` — Rod with movable end masses
Lesson 3 (Moment of inertia), Challenge slide 10.

(a) Horizontal rod 1.2 m, 0.60 kg on a vertical dashed axis through its centre, 0.20 kg point masses at each end, 0.60 m dimensioned from centre to each mass. (b) Same rod with the masses moved to 0.30 m from the centre.

Light: `light/fig-3b-challenge.png` · Dark: `dark/fig-3b-challenge.png`

### `fig-4a-review.png` — Rolling wheel velocity profile
Lesson 4 (Rotational kinetic energy), Review slide 13.

Wheel rolling right on hatched ground. Horizontal velocity arrows: 0 at contact point, v at centre, 2v at top; dashed line from contact point through the arrow tips. Curved arrow ω clockwise.

Light: `light/fig-4a-review.png` · Dark: `dark/fig-4a-review.png`

### `fig-4b-challenge.png` — Solid cylinder rolling down a slope
Lesson 4 (Rotational kinetic energy), Challenge slide 14.

Solid cylinder at top of incline, released from rest; dashed outline at the bottom with v = ? and ω = ?. Vertical drop of the centre Δh = 0.90 m as a dimension line. Part (c): block sliding on an identical frictionless slope (same height) with v = ?.

Light: `light/fig-4b-challenge.png` · Dark: `dark/fig-4b-challenge.png`

### `fig-5a-review.png` — Spinning skater: conservation of angular momentum
Lesson 5 (Angular momentum), Review slide 17.

Skater seen from above: arms out with small curved arrow ω₁ (large I₁), then arms in with larger curved arrow ω₂ (small I₂). Arrow between the two states captioned I₁ω₁ = I₂ω₂.

Light: `light/fig-5a-review.png` · Dark: `dark/fig-5a-review.png`

### `fig-5b-challenge.png` — Clay dropped onto a turntable
Lesson 5 (Angular momentum), Challenge slide 18.

Before: turntable 4.0 kg, radius 0.50 m, rotating at 3.0 rad s⁻¹ (curved arrow); 1.0 kg lump of clay falls vertically onto the rim along a dashed path. After: clay stuck at the rim, ω₂ = ?.

Light: `light/fig-5b-challenge.png` · Dark: `dark/fig-5b-challenge.png`

## Already in the deck (no new figure)

- Concept-check diagrams `img/rbm-*.png` (slides 03, 07, 11, 15, 19)
- Graph-check plots `img/rbm-graph1–5.png` (slides 04, 08, 12, 16, 20)
